import base64
hex_data ='ff66c6851bffffff32c685fafeffff39c685fffeffff618d85f4feffff83c02a66c70031338d85f4'

ascii_string = str(base64.b16decode(hex_data))[2:-1]
print (ascii_string)
